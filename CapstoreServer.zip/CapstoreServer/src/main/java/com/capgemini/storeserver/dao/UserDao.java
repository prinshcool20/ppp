package com.capgemini.storeserver.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.User1;



public interface UserDao extends JpaRepository<User1, String>{

	

}
