package com.capgemini.storeserver.services;

import java.util.List;

import com.capgemini.storeserver.exceptions.CustomerNotFoundException;
import com.capgemini.storeserver.exceptions.InvalidInputException;
import com.capgemini.storeserver.exceptions.ProductUnavailableException;
import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.User1;

public interface CustomerServices {

	
	



	

	

//	public Product getProductById(int productId) throws InvalidInputException;

	
	public List<Product> getAllProductsFromCart(String userId) throws InvalidInputException;

	
	

	Cart addProductToNewCart(String userId,int productId, int quantity) throws ProductUnavailableException;

	

	Cart removeProductFromCart(String userId,int productId);//once removed from cart, update stock & quantity in product

	

}
