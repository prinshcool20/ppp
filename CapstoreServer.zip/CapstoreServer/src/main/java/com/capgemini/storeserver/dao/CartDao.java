package com.capgemini.storeserver.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.Cart;
import com.cg.bean.User1;



public interface CartDao extends JpaRepository<Cart, Integer>{
	public Cart findByUser(User1 user);
}
