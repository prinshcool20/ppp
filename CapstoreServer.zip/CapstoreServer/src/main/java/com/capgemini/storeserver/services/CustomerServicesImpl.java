package com.capgemini.storeserver.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.storeserver.dao.CartDao;
import com.capgemini.storeserver.dao.ProductDao;
import com.capgemini.storeserver.dao.UserDao;

import com.capgemini.storeserver.exceptions.CustomerNotFoundException;
import com.capgemini.storeserver.exceptions.InvalidInputException;
import com.capgemini.storeserver.exceptions.ProductUnavailableException;
import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.User1;

@Service(value = "customerServices")
public class CustomerServicesImpl implements CustomerServices {

	User1 user;
	
	Product product;

	@Autowired
	private UserDao userdao;

	@Autowired
	private CartDao cartdao;



	@Autowired
	private ProductDao productdao;

	@Override
	public List<Product> getAllProductsFromCart(String userId) throws InvalidInputException {
		Cart cart;

		user = userdao.getOne(userId);
		cart = cartdao.findByUser(user);
		
		return cart.getProducts();
		
	}

	

//	@Override
//	public Product getProductById(int productId) throws InvalidInputException {
//		if (productdao.findByProductID(productId) != null)
//			return productdao.findByProductID(productId);
//		else
//			throw new InvalidInputException();
//	}

	

	

	

	

	
	
	@Override
	public Cart addProductToNewCart(String userId, int productId, int quantity)
			throws ProductUnavailableException {
		product = productdao.getOne(productId);
		String error = "This quantity of the product is not available";
		if (product.getQuantity() > quantity) {
			Cart cart = new Cart();
			List<Product> products = new ArrayList<Product>();
			//cart.setQuantity(quantity);
			products.add(product);
			double productPrice = product.getPrice();
			double amount = productPrice * quantity;
			cart.setAmount(amount);
			cart.setProducts(products);
			cart.setUser(userdao.getOne(userId));
			return cartdao.save(cart);
		} else
			throw new ProductUnavailableException(error);
	}



	@Override
	public Cart removeProductFromCart(String userId, int productId) {
		user = userdao.getOne(userId);
		Cart cart = cartdao.findByUser(user);
		List<Product> products = cart.getProducts();
		//int productIndex = products.indexOf(new Product(userId, null, null, userId, userId, userId, productId, userId, userId));
		int productIndex= products.indexOf(productdao.getOne(productId));
		products.remove(productIndex);
		cart.setProducts(products);
		return cartdao.save(cart);
		
	}



	



	



	





	

	

	

}
